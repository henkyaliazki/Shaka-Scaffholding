-- =====================================================
-- DATABASE SCHEMA: CV SCAFFOLDING SHAKA
-- Sistem Manajemen Penyewaan Alat Konstruksi (FIFO)
-- =====================================================

-- Buat database jika belum ada
CREATE DATABASE IF NOT EXISTS scaffolding_shaka
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE scaffolding_shaka;

-- =====================================================
-- 1. TABEL USERS (Admin/Staff)
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff') DEFAULT 'staff',
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =====================================================
-- 2. TABEL CUSTOMERS (Pelanggan)
-- =====================================================
CREATE TABLE IF NOT EXISTS customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    company_name VARCHAR(150),
    email VARCHAR(100),
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    id_card_number VARCHAR(50),
    id_card_photo VARCHAR(255),
    total_rentals INT DEFAULT 0,
    total_spent DECIMAL(15,2) DEFAULT 0,
    notes TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_phone (phone),
    INDEX idx_name (name)
);

-- =====================================================
-- 3. TABEL CATEGORIES (Kategori Alat)
-- =====================================================
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- 4. TABEL EQUIPMENT (Master Alat)
-- =====================================================
CREATE TABLE IF NOT EXISTS equipment (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    specifications JSON,
    image VARCHAR(255),
    rental_price_daily DECIMAL(12,2) NOT NULL,
    rental_price_weekly DECIMAL(12,2),
    rental_price_monthly DECIMAL(12,2),
    deposit_amount DECIMAL(12,2) DEFAULT 0,
    min_rental_days INT DEFAULT 1,
    total_stock INT DEFAULT 0,
    available_stock INT DEFAULT 0,
    rented_stock INT DEFAULT 0,
    damaged_stock INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    INDEX idx_code (code),
    INDEX idx_category (category_id),
    INDEX idx_availability (available_stock)
);

-- =====================================================
-- 5. TABEL STOCK_ITEMS (Unit Stok Individual - FIFO)
-- =====================================================
CREATE TABLE IF NOT EXISTS stock_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    equipment_id INT NOT NULL,
    serial_number VARCHAR(100) UNIQUE,
    batch_code VARCHAR(50),
    purchase_date DATE,
    purchase_price DECIMAL(12,2),
    entry_date DATETIME NOT NULL,
    condition_status ENUM('baik', 'rusak_ringan', 'rusak_berat', 'hilang') DEFAULT 'baik',
    availability_status ENUM('tersedia', 'disewa', 'maintenance', 'tidak_aktif') DEFAULT 'tersedia',
    current_rental_id INT,
    last_maintenance_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id),
    INDEX idx_equipment (equipment_id),
    INDEX idx_availability (availability_status),
    INDEX idx_fifo (equipment_id, availability_status, entry_date)
);

-- =====================================================
-- 6. TABEL RENTALS (Transaksi Penyewaan)
-- =====================================================
CREATE TABLE IF NOT EXISTS rentals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rental_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    user_id INT NOT NULL,
    rental_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    status ENUM('pending', 'active', 'overdue', 'returned', 'cancelled') DEFAULT 'pending',
    subtotal DECIMAL(15,2) NOT NULL,
    discount_amount DECIMAL(15,2) DEFAULT 0,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(15,2) DEFAULT 0,
    deposit_amount DECIMAL(15,2) DEFAULT 0,
    total_amount DECIMAL(15,2) NOT NULL,
    late_fee_per_day DECIMAL(12,2) DEFAULT 0,
    total_late_days INT DEFAULT 0,
    total_late_fee DECIMAL(15,2) DEFAULT 0,
    payment_status ENUM('unpaid', 'partial', 'paid', 'refunded') DEFAULT 'unpaid',
    paid_amount DECIMAL(15,2) DEFAULT 0,
    delivery_address TEXT,
    delivery_fee DECIMAL(12,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_rental_number (rental_number),
    INDEX idx_customer (customer_id),
    INDEX idx_status (status),
    INDEX idx_dates (rental_date, due_date)
);

-- =====================================================
-- 7. TABEL RENTAL_ITEMS (Item dalam Transaksi)
-- =====================================================
CREATE TABLE IF NOT EXISTS rental_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rental_id INT NOT NULL,
    equipment_id INT NOT NULL,
    stock_item_id INT,
    quantity INT NOT NULL DEFAULT 1,
    rental_price DECIMAL(12,2) NOT NULL,
    rental_days INT NOT NULL,
    subtotal DECIMAL(15,2) NOT NULL,
    returned_quantity INT DEFAULT 0,
    returned_date DATETIME,
    return_condition ENUM('baik', 'rusak_ringan', 'rusak_berat', 'hilang'),
    damage_fee DECIMAL(12,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (rental_id) REFERENCES rentals(id) ON DELETE CASCADE,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id),
    FOREIGN KEY (stock_item_id) REFERENCES stock_items(id),
    INDEX idx_rental (rental_id),
    INDEX idx_equipment (equipment_id)
);

-- =====================================================
-- 8. TABEL STOCK_MOVEMENTS (Pergerakan Stok - FIFO)
-- =====================================================
CREATE TABLE IF NOT EXISTS stock_movements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    stock_item_id INT,
    equipment_id INT NOT NULL,
    rental_id INT,
    movement_type ENUM('masuk', 'keluar', 'retur', 'adjustment', 'rusak', 'hilang') NOT NULL,
    quantity INT NOT NULL,
    fifo_sequence INT,
    reference_number VARCHAR(50),
    previous_stock INT,
    current_stock INT,
    movement_date DATETIME NOT NULL,
    processed_by INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stock_item_id) REFERENCES stock_items(id),
    FOREIGN KEY (equipment_id) REFERENCES equipment(id),
    FOREIGN KEY (rental_id) REFERENCES rentals(id),
    FOREIGN KEY (processed_by) REFERENCES users(id),
    INDEX idx_movement_date (movement_date),
    INDEX idx_movement_type (movement_type, equipment_id),
    INDEX idx_equipment (equipment_id)
);

-- =====================================================
-- 9. TABEL PAYMENTS (Pembayaran)
-- =====================================================
CREATE TABLE IF NOT EXISTS payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rental_id INT NOT NULL,
    payment_number VARCHAR(50) UNIQUE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_method ENUM('cash', 'transfer', 'qris', 'card') NOT NULL,
    payment_date DATETIME NOT NULL,
    bank_name VARCHAR(50),
    account_number VARCHAR(50),
    reference_number VARCHAR(100),
    proof_image VARCHAR(255),
    status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    verified_by INT,
    verified_at DATETIME,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (rental_id) REFERENCES rentals(id),
    FOREIGN KEY (verified_by) REFERENCES users(id),
    INDEX idx_rental (rental_id),
    INDEX idx_payment_date (payment_date)
);

-- =====================================================
-- 10. TABEL SETTINGS (Pengaturan Sistem)
-- =====================================================
CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description VARCHAR(255),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =====================================================
-- INSERT DATA DEFAULT
-- =====================================================

-- Default admin user (password: admin123 - hashed with bcrypt)
INSERT INTO users (name, email, password, role, is_active) VALUES
('Administrator', 'admin@scaffoldingshaka.com', '$2b$10$rIC/EbYxYwMBr5CkJhQ7C.sZoB4JcLzKxgwOC8qJFkQVpV.5KxVXi', 'admin', TRUE),
('Staff Demo', 'staff@scaffoldingshaka.com', '$2b$10$rIC/EbYxYwMBr5CkJhQ7C.sZoB4JcLzKxgwOC8qJFkQVpV.5KxVXi', 'staff', TRUE);

-- Default categories
INSERT INTO categories (name, slug, description, icon) VALUES
('Scaffolding', 'scaffolding', 'Perancah untuk konstruksi bangunan', 'Building2'),
('Bekisting', 'bekisting', 'Cetakan untuk pengecoran beton', 'Square'),
('Shoring', 'shoring', 'Penopang sementara untuk struktur', 'ArrowUpDown'),
('Accessories', 'accessories', 'Aksesoris dan perlengkapan pendukung', 'Wrench'),
('Safety Equipment', 'safety-equipment', 'Peralatan keselamatan kerja', 'ShieldCheck');

-- Default equipment
INSERT INTO equipment (category_id, code, name, description, specifications, rental_price_daily, rental_price_weekly, rental_price_monthly, total_stock, available_stock) VALUES
(1, 'SCF-001', 'Scaffolding Frame 1.7m', 'Frame scaffolding standar tinggi 1.7 meter', '{"material": "Besi Galvanis", "ukuran": "1.7m x 1.2m", "berat": "18 kg", "kapasitas": "500 kg"}', 15000, 90000, 350000, 100, 100),
(1, 'SCF-002', 'Scaffolding Frame 0.9m', 'Frame scaffolding setengah tinggi 0.9 meter', '{"material": "Besi Galvanis", "ukuran": "0.9m x 1.2m", "berat": "12 kg", "kapasitas": "500 kg"}', 12000, 72000, 280000, 80, 80),
(1, 'SCF-003', 'Cross Brace 1.7m', 'Penguat silang untuk scaffolding 1.7m', '{"material": "Besi Galvanis", "ukuran": "2.0m", "berat": "4 kg"}', 5000, 30000, 120000, 200, 200),
(1, 'SCF-004', 'Base Jack', 'Jack dasar scaffolding dengan ulir', '{"material": "Besi", "ulir": "60 cm", "berat": "5 kg"}', 3000, 18000, 70000, 150, 150),
(2, 'BKT-001', 'Panel Bekisting 120x60', 'Panel bekisting kayu lapis ukuran standar', '{"material": "Plywood 18mm", "ukuran": "120cm x 60cm", "berat": "15 kg"}', 8000, 48000, 180000, 200, 200),
(2, 'BKT-002', 'Panel Bekisting 120x30', 'Panel bekisting kayu lapis ukuran kecil', '{"material": "Plywood 18mm", "ukuran": "120cm x 30cm", "berat": "8 kg"}', 5000, 30000, 110000, 150, 150),
(3, 'SHR-001', 'Push Pull Prop 3.5m', 'Tiang penopang adjustable 3.5 meter', '{"material": "Besi", "panjang": "2.0m - 3.5m", "berat": "15 kg", "kapasitas": "2000 kg"}', 20000, 120000, 450000, 50, 50),
(3, 'SHR-002', 'Push Pull Prop 4.0m', 'Tiang penopang adjustable 4.0 meter', '{"material": "Besi", "panjang": "2.5m - 4.0m", "berat": "18 kg", "kapasitas": "2000 kg"}', 25000, 150000, 550000, 40, 40),
(4, 'ACC-001', 'Scaffold Plank 2m', 'Papan pijakan scaffolding 2 meter', '{"material": "Besi Galvanis", "ukuran": "2m x 30cm", "berat": "12 kg"}', 8000, 48000, 180000, 100, 100),
(4, 'ACC-002', 'Swivel Clamp', 'Klem putar serbaguna', '{"material": "Besi Tempa", "ukuran": "48.3mm", "berat": "1 kg"}', 2000, 12000, 45000, 300, 300),
(5, 'SAF-001', 'Safety Helmet', 'Helm keselamatan standar SNI', '{"material": "ABS Plastic", "warna": "Kuning/Putih", "standar": "SNI"}', 5000, 30000, 100000, 50, 50),
(5, 'SAF-002', 'Safety Harness', 'Full body harness dengan lanyard', '{"material": "Polyester", "kapasitas": "150 kg", "standar": "SNI"}', 15000, 90000, 300000, 30, 30);

-- Insert stock items for FIFO tracking
INSERT INTO stock_items (equipment_id, batch_code, entry_date, condition_status, availability_status)
SELECT 
    e.id,
    CONCAT('BATCH-2024-', e.code),
    DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 30) DAY),
    'baik',
    'tersedia'
FROM equipment e
CROSS JOIN (
    SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5
    UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9 UNION SELECT 10
) AS numbers
WHERE e.total_stock >= 10
LIMIT 120;

-- Default settings
INSERT INTO settings (setting_key, setting_value, setting_type, description) VALUES
('company_name', 'CV Scaffolding Shaka', 'string', 'Nama perusahaan'),
('company_address', 'Jl. Konstruksi No. 123, Jakarta Timur 13450', 'string', 'Alamat perusahaan'),
('company_phone', '021-1234567', 'string', 'Telepon perusahaan'),
('company_whatsapp', '081234567890', 'string', 'Nomor WhatsApp'),
('company_email', 'info@scaffoldingshaka.com', 'string', 'Email perusahaan'),
('late_fee_percentage', '10', 'number', 'Persentase denda keterlambatan per hari'),
('tax_percentage', '11', 'number', 'Persentase PPN'),
('rental_number_prefix', 'TRX', 'string', 'Prefix nomor transaksi'),
('min_rental_days', '1', 'number', 'Minimal hari sewa'),
('max_discount_percentage', '20', 'number', 'Maksimal diskon (%)');

-- Sample customers
INSERT INTO customers (name, company_name, email, phone, address) VALUES
('Budi Santoso', 'PT Bangun Jaya', 'budi@bangunjaya.com', '081234567891', 'Jl. Merdeka No. 45, Jakarta'),
('Ahmad Rahman', 'CV Konstruksi Mandiri', 'ahmad@konstruksimandiri.com', '081234567892', 'Jl. Sudirman No. 78, Bandung'),
('Dewi Lestari', 'PT Griya Indah', 'dewi@griyaindah.com', '081234567893', 'Jl. Gatot Subroto No. 12, Surabaya'),
('Eko Prasetyo', NULL, 'eko.prasetyo@gmail.com', '081234567894', 'Jl. Ahmad Yani No. 56, Semarang'),
('Siti Nurhaliza', 'CV Beton Prima', 'siti@betonprima.com', '081234567895', 'Jl. Diponegoro No. 89, Yogyakarta');

-- =====================================================
-- VIEWS
-- =====================================================

-- View: Ketersediaan Alat Real-time
CREATE OR REPLACE VIEW v_equipment_availability AS
SELECT 
    e.id,
    e.code,
    e.name,
    c.name as category_name,
    e.total_stock,
    e.available_stock,
    e.rented_stock,
    e.damaged_stock,
    e.rental_price_daily,
    CASE 
        WHEN e.available_stock > 0 THEN 'Tersedia'
        WHEN e.available_stock = 0 AND e.rented_stock > 0 THEN 'Habis Disewa'
        ELSE 'Tidak Tersedia'
    END as availability_label
FROM equipment e
JOIN categories c ON e.category_id = c.id
WHERE e.is_active = TRUE;

-- View: Transaksi Aktif
CREATE OR REPLACE VIEW v_active_rentals AS
SELECT 
    r.id,
    r.rental_number,
    c.name as customer_name,
    c.phone as customer_phone,
    r.rental_date,
    r.due_date,
    DATEDIFF(r.due_date, CURDATE()) as days_remaining,
    r.total_amount,
    r.payment_status,
    r.status
FROM rentals r
JOIN customers c ON r.customer_id = c.id
WHERE r.status IN ('active', 'overdue')
ORDER BY r.due_date ASC;

-- =====================================================
-- STORED PROCEDURES
-- =====================================================

DELIMITER //

-- Procedure: Update overdue rentals
CREATE PROCEDURE sp_update_overdue_rentals()
BEGIN
    UPDATE rentals 
    SET status = 'overdue',
        total_late_days = DATEDIFF(CURDATE(), due_date),
        total_late_fee = DATEDIFF(CURDATE(), due_date) * late_fee_per_day
    WHERE status = 'active' 
    AND due_date < CURDATE();
END //

-- Procedure: Process rental with FIFO
CREATE PROCEDURE sp_process_rental_fifo(
    IN p_rental_id INT,
    IN p_equipment_id INT,
    IN p_quantity INT
)
BEGIN
    DECLARE v_stock_item_id INT;
    DECLARE v_count INT DEFAULT 0;
    DECLARE done INT DEFAULT FALSE;
    
    DECLARE fifo_cursor CURSOR FOR
        SELECT id FROM stock_items
        WHERE equipment_id = p_equipment_id
        AND availability_status = 'tersedia'
        ORDER BY entry_date ASC
        LIMIT p_quantity;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN fifo_cursor;
    
    fifo_loop: LOOP
        FETCH fifo_cursor INTO v_stock_item_id;
        IF done THEN
            LEAVE fifo_loop;
        END IF;
        
        UPDATE stock_items 
        SET availability_status = 'disewa',
            current_rental_id = p_rental_id
        WHERE id = v_stock_item_id;
        
        INSERT INTO stock_movements (
            stock_item_id, equipment_id, rental_id,
            movement_type, quantity, movement_date
        ) VALUES (
            v_stock_item_id, p_equipment_id, p_rental_id,
            'keluar', 1, NOW()
        );
        
        SET v_count = v_count + 1;
    END LOOP;
    
    CLOSE fifo_cursor;
    
    UPDATE equipment
    SET available_stock = available_stock - v_count,
        rented_stock = rented_stock + v_count
    WHERE id = p_equipment_id;
    
END //

DELIMITER ;

-- =====================================================
-- EVENT SCHEDULER (Optional - untuk auto-update overdue)
-- =====================================================
-- SET GLOBAL event_scheduler = ON;
-- CREATE EVENT IF NOT EXISTS evt_update_overdue_rentals
-- ON SCHEDULE EVERY 1 DAY
-- STARTS CURRENT_DATE + INTERVAL 1 DAY
-- DO CALL sp_update_overdue_rentals();
