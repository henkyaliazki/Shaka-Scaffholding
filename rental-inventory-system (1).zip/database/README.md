# Database Setup - CV Scaffolding Shaka

## Environment Variables

Tambahkan environment variables berikut ke file `.env.local`:

```env
# MySQL Database Configuration
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your_password
MYSQL_DATABASE=scaffolding_shaka
```

## Cara Setup Database

### 1. Buat Database

Login ke MySQL dan jalankan:

```bash
mysql -u root -p
```

```sql
CREATE DATABASE scaffolding_shaka CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. Import Schema

```bash
mysql -u root -p scaffolding_shaka < database/schema.sql
```

Atau copy-paste isi file `database/schema.sql` ke MySQL client.

### 3. Verifikasi Instalasi

```sql
USE scaffolding_shaka;
SHOW TABLES;
```

Harus muncul 10 tabel:
- users
- customers
- categories
- equipment
- stock_items
- rentals
- rental_items
- stock_movements
- payments
- settings

## Default Login

Setelah import schema, user default:

| Email | Password | Role |
|-------|----------|------|
| admin@scaffoldingshaka.com | admin123 | Admin |
| staff@scaffoldingshaka.com | admin123 | Staff |

**Catatan:** Password di-hash menggunakan bcrypt. Ganti password default setelah instalasi.

## Struktur Tabel

### Tabel Utama

| Tabel | Fungsi |
|-------|--------|
| `users` | Data admin/staff sistem |
| `customers` | Data pelanggan |
| `categories` | Kategori alat (Scaffolding, Bekisting, dll) |
| `equipment` | Master data alat dengan harga sewa |
| `stock_items` | Unit stok individual untuk tracking FIFO |
| `rentals` | Header transaksi penyewaan |
| `rental_items` | Detail item per transaksi |
| `stock_movements` | Log pergerakan stok (FIFO audit trail) |
| `payments` | Catatan pembayaran |
| `settings` | Pengaturan sistem |

### Views

| View | Fungsi |
|------|--------|
| `v_equipment_availability` | Ketersediaan alat real-time |
| `v_active_rentals` | Transaksi aktif dan overdue |

### Stored Procedures

| Procedure | Fungsi |
|-----------|--------|
| `sp_update_overdue_rentals` | Update status transaksi yang overdue |
| `sp_process_rental_fifo` | Proses penyewaan dengan algoritma FIFO |

## API Endpoints

| Method | Endpoint | Fungsi |
|--------|----------|--------|
| GET | `/api/equipment` | Daftar alat |
| GET | `/api/categories` | Daftar kategori |
| GET/POST | `/api/customers` | CRUD pelanggan |
| GET/POST | `/api/rentals` | CRUD transaksi |
| GET/PATCH | `/api/rentals/[id]` | Detail & update transaksi |
| POST | `/api/stock` | Tambah stok |
| GET | `/api/stock-movements` | Riwayat pergerakan stok |
| GET | `/api/dashboard/stats` | Statistik dashboard |

## Algoritma FIFO

Sistem menggunakan metode **First In First Out (FIFO)** untuk pengelolaan stok:

1. Setiap unit alat dicatat di tabel `stock_items` dengan `entry_date`
2. Saat penyewaan, unit dengan `entry_date` paling lama dipilih terlebih dahulu
3. Semua pergerakan dicatat di `stock_movements` untuk audit trail
4. Ketersediaan real-time dihitung dari `availability_status` di `stock_items`
