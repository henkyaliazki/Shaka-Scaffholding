import { NextResponse } from 'next/server';
import { addStock } from '@/lib/db';
import type { AddStockInput } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const body: AddStockInput = await request.json();

    if (!body.equipment_id || !body.quantity || body.quantity <= 0) {
      return NextResponse.json(
        { success: false, error: 'ID alat dan jumlah stok wajib diisi' },
        { status: 400 }
      );
    }

    const stockItemIds = await addStock(body);

    return NextResponse.json({
      success: true,
      data: { ids: stockItemIds },
      message: `${body.quantity} unit stok berhasil ditambahkan`,
    });
  } catch (error) {
    console.error('Error adding stock:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal menambahkan stok' },
      { status: 500 }
    );
  }
}
