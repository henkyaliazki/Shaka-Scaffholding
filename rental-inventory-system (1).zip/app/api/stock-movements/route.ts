import { NextResponse } from 'next/server';
import { getStockMovements } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const equipment_id = searchParams.get('equipment_id');
    const movement_type = searchParams.get('movement_type');
    const date_from = searchParams.get('date_from');
    const date_to = searchParams.get('date_to');

    const movements = await getStockMovements({
      equipment_id: equipment_id ? parseInt(equipment_id) : undefined,
      movement_type: movement_type || undefined,
      date_from: date_from || undefined,
      date_to: date_to || undefined,
    });

    return NextResponse.json({
      success: true,
      data: movements,
    });
  } catch (error) {
    console.error('Error fetching stock movements:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal mengambil data pergerakan stok' },
      { status: 500 }
    );
  }
}
