import { NextResponse } from 'next/server';
import { getCustomers, createCustomer } from '@/lib/db';
import type { CreateCustomerInput } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');

    const customers = await getCustomers(search || undefined);

    return NextResponse.json({
      success: true,
      data: customers,
    });
  } catch (error) {
    console.error('Error fetching customers:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal mengambil data pelanggan' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body: CreateCustomerInput = await request.json();

    if (!body.name || !body.phone) {
      return NextResponse.json(
        { success: false, error: 'Nama dan nomor telepon wajib diisi' },
        { status: 400 }
      );
    }

    const customerId = await createCustomer(body);

    return NextResponse.json({
      success: true,
      data: { id: customerId },
      message: 'Pelanggan berhasil ditambahkan',
    });
  } catch (error) {
    console.error('Error creating customer:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal menambahkan pelanggan' },
      { status: 500 }
    );
  }
}
