import { NextResponse } from 'next/server';
import { getRentalById, processReturn } from '@/lib/db';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const rental = await getRentalById(parseInt(id));

    if (!rental) {
      return NextResponse.json(
        { success: false, error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: rental,
    });
  } catch (error) {
    console.error('Error fetching rental:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal mengambil data transaksi' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    if (body.action === 'return') {
      await processReturn(parseInt(id), body.items);

      return NextResponse.json({
        success: true,
        message: 'Pengembalian berhasil diproses',
      });
    }

    return NextResponse.json(
      { success: false, error: 'Aksi tidak valid' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Error processing rental:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal memproses transaksi' },
      { status: 500 }
    );
  }
}
