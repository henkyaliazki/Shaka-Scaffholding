import { NextResponse } from 'next/server';
import { getRentals, createRental } from '@/lib/db';
import type { CreateRentalInput } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const customer_id = searchParams.get('customer_id');
    const date_from = searchParams.get('date_from');
    const date_to = searchParams.get('date_to');

    const rentals = await getRentals({
      status: status || undefined,
      customer_id: customer_id ? parseInt(customer_id) : undefined,
      date_from: date_from || undefined,
      date_to: date_to || undefined,
    });

    return NextResponse.json({
      success: true,
      data: rentals,
    });
  } catch (error) {
    console.error('Error fetching rentals:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal mengambil data transaksi' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body: CreateRentalInput = await request.json();

    // TODO: Get actual user ID from session/auth
    const userId = 1;

    if (!body.customer_id || !body.items || body.items.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Data transaksi tidak lengkap' },
        { status: 400 }
      );
    }

    const rentalId = await createRental(body, userId);

    return NextResponse.json({
      success: true,
      data: { id: rentalId },
      message: 'Transaksi berhasil dibuat',
    });
  } catch (error) {
    console.error('Error creating rental:', error);
    const message = error instanceof Error ? error.message : 'Gagal membuat transaksi';
    return NextResponse.json(
      { success: false, error: message },
      { status: 500 }
    );
  }
}
