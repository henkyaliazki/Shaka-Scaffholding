import { NextResponse } from 'next/server';
import { getEquipment } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category_id = searchParams.get('category_id');
    const search = searchParams.get('search');
    const availability = searchParams.get('availability') as 'all' | 'available' | 'unavailable' | null;

    const equipment = await getEquipment({
      category_id: category_id ? parseInt(category_id) : undefined,
      search: search || undefined,
      availability: availability || undefined,
    });

    return NextResponse.json({
      success: true,
      data: equipment,
    });
  } catch (error) {
    console.error('Error fetching equipment:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal mengambil data alat' },
      { status: 500 }
    );
  }
}
