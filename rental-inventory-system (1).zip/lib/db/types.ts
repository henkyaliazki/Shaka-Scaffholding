// =====================================================
// DATABASE TYPES: CV SCAFFOLDING SHAKA
// =====================================================

// User (Admin/Staff)
export interface User {
  id: number;
  name: string;
  email: string;
  password?: string;
  role: 'admin' | 'staff';
  phone?: string;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

// Customer (Pelanggan)
export interface Customer {
  id: number;
  name: string;
  company_name?: string;
  email?: string;
  phone: string;
  address?: string;
  id_card_number?: string;
  id_card_photo?: string;
  total_rentals: number;
  total_spent: number;
  notes?: string;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

// Category (Kategori Alat)
export interface Category {
  id: number;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  is_active: boolean;
  created_at: Date;
}

// Equipment Specifications
export interface EquipmentSpecs {
  material?: string;
  ukuran?: string;
  berat?: string;
  kapasitas?: string;
  [key: string]: string | undefined;
}

// Equipment (Master Alat)
export interface Equipment {
  id: number;
  category_id: number;
  code: string;
  name: string;
  description?: string;
  specifications?: EquipmentSpecs;
  image?: string;
  rental_price_daily: number;
  rental_price_weekly?: number;
  rental_price_monthly?: number;
  deposit_amount: number;
  min_rental_days: number;
  total_stock: number;
  available_stock: number;
  rented_stock: number;
  damaged_stock: number;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
  // Joined fields
  category_name?: string;
}

// Stock Item (Unit Individual - FIFO)
export interface StockItem {
  id: number;
  equipment_id: number;
  serial_number?: string;
  batch_code?: string;
  purchase_date?: Date;
  purchase_price?: number;
  entry_date: Date;
  condition_status: 'baik' | 'rusak_ringan' | 'rusak_berat' | 'hilang';
  availability_status: 'tersedia' | 'disewa' | 'maintenance' | 'tidak_aktif';
  current_rental_id?: number;
  last_maintenance_date?: Date;
  notes?: string;
  created_at: Date;
  updated_at: Date;
  // Joined fields
  equipment_name?: string;
  equipment_code?: string;
}

// Rental (Transaksi Penyewaan)
export interface Rental {
  id: number;
  rental_number: string;
  customer_id: number;
  user_id: number;
  rental_date: Date;
  due_date: Date;
  return_date?: Date;
  status: 'pending' | 'active' | 'overdue' | 'returned' | 'cancelled';
  subtotal: number;
  discount_amount: number;
  discount_percentage: number;
  tax_amount: number;
  deposit_amount: number;
  total_amount: number;
  late_fee_per_day: number;
  total_late_days: number;
  total_late_fee: number;
  payment_status: 'unpaid' | 'partial' | 'paid' | 'refunded';
  paid_amount: number;
  delivery_address?: string;
  delivery_fee: number;
  notes?: string;
  created_at: Date;
  updated_at: Date;
  // Joined fields
  customer_name?: string;
  customer_phone?: string;
  customer_company?: string;
  processed_by?: string;
  items?: RentalItem[];
}

// Rental Item (Detail Item Transaksi)
export interface RentalItem {
  id: number;
  rental_id: number;
  equipment_id: number;
  stock_item_id?: number;
  quantity: number;
  rental_price: number;
  rental_days: number;
  subtotal: number;
  returned_quantity: number;
  returned_date?: Date;
  return_condition?: 'baik' | 'rusak_ringan' | 'rusak_berat' | 'hilang';
  damage_fee: number;
  notes?: string;
  created_at: Date;
  // Joined fields
  equipment_name?: string;
  equipment_code?: string;
}

// Stock Movement (Pergerakan Stok - FIFO)
export interface StockMovement {
  id: number;
  stock_item_id?: number;
  equipment_id: number;
  rental_id?: number;
  movement_type: 'masuk' | 'keluar' | 'retur' | 'adjustment' | 'rusak' | 'hilang';
  quantity: number;
  fifo_sequence?: number;
  reference_number?: string;
  previous_stock: number;
  current_stock: number;
  movement_date: Date;
  processed_by?: number;
  notes?: string;
  created_at: Date;
  // Joined fields
  equipment_name?: string;
  equipment_code?: string;
  processor_name?: string;
  rental_number?: string;
}

// Payment (Pembayaran)
export interface Payment {
  id: number;
  rental_id: number;
  payment_number: string;
  amount: number;
  payment_method: 'cash' | 'transfer' | 'qris' | 'card';
  payment_date: Date;
  bank_name?: string;
  account_number?: string;
  reference_number?: string;
  proof_image?: string;
  status: 'pending' | 'verified' | 'rejected';
  verified_by?: number;
  verified_at?: Date;
  notes?: string;
  created_at: Date;
  // Joined fields
  rental_number?: string;
  verifier_name?: string;
}

// Settings
export interface Setting {
  id: number;
  setting_key: string;
  setting_value: string;
  setting_type: 'string' | 'number' | 'boolean' | 'json';
  description?: string;
  updated_at: Date;
}

// =====================================================
// API Response Types
// =====================================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// =====================================================
// Dashboard Stats
// =====================================================

export interface DashboardStats {
  totalEquipment: number;
  availableUnits: number;
  rentedUnits: number;
  totalCustomers: number;
  activeRentals: number;
  overdueRentals: number;
  monthlyRevenue: number;
  pendingPayments: number;
}

// =====================================================
// Form Input Types
// =====================================================

export interface CreateCustomerInput {
  name: string;
  company_name?: string;
  email?: string;
  phone: string;
  address?: string;
  id_card_number?: string;
  notes?: string;
}

export interface CreateEquipmentInput {
  category_id: number;
  code: string;
  name: string;
  description?: string;
  specifications?: EquipmentSpecs;
  image?: string;
  rental_price_daily: number;
  rental_price_weekly?: number;
  rental_price_monthly?: number;
  deposit_amount?: number;
  min_rental_days?: number;
}

export interface CreateRentalInput {
  customer_id: number;
  rental_date: string;
  due_date: string;
  items: {
    equipment_id: number;
    quantity: number;
    rental_days: number;
  }[];
  discount_percentage?: number;
  delivery_address?: string;
  delivery_fee?: number;
  notes?: string;
}

export interface AddStockInput {
  equipment_id: number;
  quantity: number;
  batch_code?: string;
  purchase_date?: string;
  purchase_price?: number;
  notes?: string;
}

export interface ProcessReturnInput {
  rental_id: number;
  items: {
    rental_item_id: number;
    returned_quantity: number;
    return_condition: 'baik' | 'rusak_ringan' | 'rusak_berat' | 'hilang';
    damage_fee?: number;
  }[];
  notes?: string;
}
