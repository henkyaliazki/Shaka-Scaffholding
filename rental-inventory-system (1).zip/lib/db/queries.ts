import { query, queryOne, insert, execute, transaction } from './connection';
import type {
  Equipment,
  Category,
  Customer,
  Rental,
  RentalItem,
  StockItem,
  StockMovement,
  DashboardStats,
  CreateEquipmentInput,
  CreateCustomerInput,
  CreateRentalInput,
  AddStockInput,
} from './types';
import mysql from 'mysql2/promise';

// =====================================================
// CATEGORIES
// =====================================================

export async function getCategories(): Promise<Category[]> {
  return query<Category[]>(
    'SELECT * FROM categories WHERE is_active = TRUE ORDER BY name'
  );
}

export async function getCategoryById(id: number): Promise<Category | null> {
  return queryOne<Category>('SELECT * FROM categories WHERE id = ?', [id]);
}

export async function createCategory(
  name: string,
  slug: string,
  description?: string,
  icon?: string
): Promise<number> {
  return insert(
    'INSERT INTO categories (name, slug, description, icon) VALUES (?, ?, ?, ?)',
    [name, slug, description || null, icon || null]
  );
}

// =====================================================
// EQUIPMENT
// =====================================================

export async function getEquipment(filters?: {
  category_id?: number;
  search?: string;
  availability?: 'all' | 'available' | 'unavailable';
}): Promise<Equipment[]> {
  let sql = `
    SELECT e.*, c.name as category_name 
    FROM equipment e
    JOIN categories c ON e.category_id = c.id
    WHERE e.is_active = TRUE
  `;
  const params: (string | number)[] = [];

  if (filters?.category_id) {
    sql += ' AND e.category_id = ?';
    params.push(filters.category_id);
  }

  if (filters?.search) {
    sql += ' AND (e.name LIKE ? OR e.code LIKE ? OR e.description LIKE ?)';
    const searchTerm = `%${filters.search}%`;
    params.push(searchTerm, searchTerm, searchTerm);
  }

  if (filters?.availability === 'available') {
    sql += ' AND e.available_stock > 0';
  } else if (filters?.availability === 'unavailable') {
    sql += ' AND e.available_stock = 0';
  }

  sql += ' ORDER BY e.name';

  return query<Equipment[]>(sql, params);
}

export async function getEquipmentById(id: number): Promise<Equipment | null> {
  return queryOne<Equipment>(
    `SELECT e.*, c.name as category_name 
     FROM equipment e
     JOIN categories c ON e.category_id = c.id
     WHERE e.id = ?`,
    [id]
  );
}

export async function createEquipment(data: CreateEquipmentInput): Promise<number> {
  return insert(
    `INSERT INTO equipment (
      category_id, code, name, description, specifications, image,
      rental_price_daily, rental_price_weekly, rental_price_monthly,
      deposit_amount, min_rental_days, total_stock, available_stock
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0)`,
    [
      data.category_id,
      data.code,
      data.name,
      data.description || null,
      data.specifications ? JSON.stringify(data.specifications) : null,
      data.image || null,
      data.rental_price_daily,
      data.rental_price_weekly || null,
      data.rental_price_monthly || null,
      data.deposit_amount || 0,
      data.min_rental_days || 1,
    ]
  );
}

export async function updateEquipment(
  id: number,
  data: Partial<CreateEquipmentInput>
): Promise<number> {
  const fields: string[] = [];
  const params: (string | number | null)[] = [];

  if (data.category_id !== undefined) {
    fields.push('category_id = ?');
    params.push(data.category_id);
  }
  if (data.name !== undefined) {
    fields.push('name = ?');
    params.push(data.name);
  }
  if (data.description !== undefined) {
    fields.push('description = ?');
    params.push(data.description);
  }
  if (data.rental_price_daily !== undefined) {
    fields.push('rental_price_daily = ?');
    params.push(data.rental_price_daily);
  }
  if (data.specifications !== undefined) {
    fields.push('specifications = ?');
    params.push(JSON.stringify(data.specifications));
  }

  if (fields.length === 0) return 0;

  params.push(id);
  return execute(
    `UPDATE equipment SET ${fields.join(', ')} WHERE id = ?`,
    params
  );
}

// =====================================================
// STOCK ITEMS (FIFO)
// =====================================================

export async function getStockItems(equipmentId: number): Promise<StockItem[]> {
  return query<StockItem[]>(
    `SELECT si.*, e.name as equipment_name, e.code as equipment_code
     FROM stock_items si
     JOIN equipment e ON si.equipment_id = e.id
     WHERE si.equipment_id = ?
     ORDER BY si.entry_date ASC`,
    [equipmentId]
  );
}

export async function getAvailableStockFIFO(
  equipmentId: number,
  quantity: number
): Promise<StockItem[]> {
  return query<StockItem[]>(
    `SELECT * FROM stock_items
     WHERE equipment_id = ? AND availability_status = 'tersedia'
     ORDER BY entry_date ASC
     LIMIT ?`,
    [equipmentId, quantity]
  );
}

export async function addStock(data: AddStockInput): Promise<number[]> {
  const ids: number[] = [];
  
  await transaction(async (connection) => {
    for (let i = 0; i < data.quantity; i++) {
      const [result] = await connection.execute(
        `INSERT INTO stock_items (
          equipment_id, batch_code, purchase_date, purchase_price,
          entry_date, condition_status, availability_status, notes
        ) VALUES (?, ?, ?, ?, NOW(), 'baik', 'tersedia', ?)`,
        [
          data.equipment_id,
          data.batch_code || null,
          data.purchase_date || null,
          data.purchase_price || null,
          data.notes || null,
        ]
      );
      ids.push((result as mysql.ResultSetHeader).insertId);
    }

    // Update equipment stock counts
    await connection.execute(
      `UPDATE equipment 
       SET total_stock = total_stock + ?, available_stock = available_stock + ?
       WHERE id = ?`,
      [data.quantity, data.quantity, data.equipment_id]
    );

    // Record stock movement
    await connection.execute(
      `INSERT INTO stock_movements (
        equipment_id, movement_type, quantity, movement_date, notes
      ) VALUES (?, 'masuk', ?, NOW(), ?)`,
      [data.equipment_id, data.quantity, data.notes || 'Penambahan stok baru']
    );
  });

  return ids;
}

// =====================================================
// CUSTOMERS
// =====================================================

export async function getCustomers(search?: string): Promise<Customer[]> {
  let sql = 'SELECT * FROM customers WHERE is_active = TRUE';
  const params: string[] = [];

  if (search) {
    sql += ' AND (name LIKE ? OR company_name LIKE ? OR phone LIKE ? OR email LIKE ?)';
    const searchTerm = `%${search}%`;
    params.push(searchTerm, searchTerm, searchTerm, searchTerm);
  }

  sql += ' ORDER BY name';

  return query<Customer[]>(sql, params);
}

export async function getCustomerById(id: number): Promise<Customer | null> {
  return queryOne<Customer>('SELECT * FROM customers WHERE id = ?', [id]);
}

export async function createCustomer(data: CreateCustomerInput): Promise<number> {
  return insert(
    `INSERT INTO customers (name, company_name, email, phone, address, id_card_number, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      data.name,
      data.company_name || null,
      data.email || null,
      data.phone,
      data.address || null,
      data.id_card_number || null,
      data.notes || null,
    ]
  );
}

export async function updateCustomer(
  id: number,
  data: Partial<CreateCustomerInput>
): Promise<number> {
  const fields: string[] = [];
  const params: (string | null)[] = [];

  Object.entries(data).forEach(([key, value]) => {
    fields.push(`${key} = ?`);
    params.push(value || null);
  });

  if (fields.length === 0) return 0;

  params.push(id.toString());
  return execute(
    `UPDATE customers SET ${fields.join(', ')} WHERE id = ?`,
    params
  );
}

// =====================================================
// RENTALS
// =====================================================

export async function getRentals(filters?: {
  status?: string;
  customer_id?: number;
  date_from?: string;
  date_to?: string;
}): Promise<Rental[]> {
  let sql = `
    SELECT r.*, c.name as customer_name, c.phone as customer_phone, 
           c.company_name as customer_company, u.name as processed_by
    FROM rentals r
    JOIN customers c ON r.customer_id = c.id
    JOIN users u ON r.user_id = u.id
    WHERE 1=1
  `;
  const params: (string | number)[] = [];

  if (filters?.status) {
    sql += ' AND r.status = ?';
    params.push(filters.status);
  }

  if (filters?.customer_id) {
    sql += ' AND r.customer_id = ?';
    params.push(filters.customer_id);
  }

  if (filters?.date_from) {
    sql += ' AND r.rental_date >= ?';
    params.push(filters.date_from);
  }

  if (filters?.date_to) {
    sql += ' AND r.rental_date <= ?';
    params.push(filters.date_to);
  }

  sql += ' ORDER BY r.created_at DESC';

  return query<Rental[]>(sql, params);
}

export async function getRentalById(id: number): Promise<Rental | null> {
  const rental = await queryOne<Rental>(
    `SELECT r.*, c.name as customer_name, c.phone as customer_phone,
            c.company_name as customer_company, u.name as processed_by
     FROM rentals r
     JOIN customers c ON r.customer_id = c.id
     JOIN users u ON r.user_id = u.id
     WHERE r.id = ?`,
    [id]
  );

  if (rental) {
    rental.items = await query<RentalItem[]>(
      `SELECT ri.*, e.name as equipment_name, e.code as equipment_code
       FROM rental_items ri
       JOIN equipment e ON ri.equipment_id = e.id
       WHERE ri.rental_id = ?`,
      [id]
    );
  }

  return rental;
}

export async function generateRentalNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const result = await queryOne<{ count: number }>(
    `SELECT COUNT(*) as count FROM rentals WHERE YEAR(created_at) = ?`,
    [year]
  );
  const count = (result?.count || 0) + 1;
  return `TRX-${year}-${count.toString().padStart(4, '0')}`;
}

export async function createRental(
  data: CreateRentalInput,
  userId: number
): Promise<number> {
  return transaction(async (connection) => {
    const rentalNumber = await generateRentalNumber();
    
    // Calculate totals
    let subtotal = 0;
    const itemsWithPrices: Array<{
      equipment_id: number;
      quantity: number;
      rental_days: number;
      rental_price: number;
      subtotal: number;
    }> = [];

    for (const item of data.items) {
      const [equipmentRows] = await connection.execute<mysql.RowDataPacket[]>(
        'SELECT rental_price_daily, available_stock FROM equipment WHERE id = ?',
        [item.equipment_id]
      );
      
      const equipment = equipmentRows[0];
      if (!equipment) throw new Error(`Alat dengan ID ${item.equipment_id} tidak ditemukan`);
      if (equipment.available_stock < item.quantity) {
        throw new Error(`Stok tidak mencukupi untuk alat ID ${item.equipment_id}`);
      }

      const itemSubtotal = equipment.rental_price_daily * item.quantity * item.rental_days;
      subtotal += itemSubtotal;
      
      itemsWithPrices.push({
        ...item,
        rental_price: equipment.rental_price_daily,
        subtotal: itemSubtotal,
      });
    }

    const discountAmount = subtotal * (data.discount_percentage || 0) / 100;
    const taxAmount = (subtotal - discountAmount) * 0.11; // 11% PPN
    const totalAmount = subtotal - discountAmount + taxAmount + (data.delivery_fee || 0);

    // Create rental
    const [rentalResult] = await connection.execute(
      `INSERT INTO rentals (
        rental_number, customer_id, user_id, rental_date, due_date,
        status, subtotal, discount_amount, discount_percentage, tax_amount,
        total_amount, delivery_address, delivery_fee, notes, payment_status
      ) VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, 'unpaid')`,
      [
        rentalNumber,
        data.customer_id,
        userId,
        data.rental_date,
        data.due_date,
        subtotal,
        discountAmount,
        data.discount_percentage || 0,
        taxAmount,
        totalAmount,
        data.delivery_address || null,
        data.delivery_fee || 0,
        data.notes || null,
      ]
    );

    const rentalId = (rentalResult as mysql.ResultSetHeader).insertId;

    // Create rental items and update stock (FIFO)
    for (const item of itemsWithPrices) {
      // Get available stock using FIFO
      const [stockItems] = await connection.execute<mysql.RowDataPacket[]>(
        `SELECT id FROM stock_items 
         WHERE equipment_id = ? AND availability_status = 'tersedia'
         ORDER BY entry_date ASC
         LIMIT ?`,
        [item.equipment_id, item.quantity]
      );

      for (let i = 0; i < item.quantity; i++) {
        const stockItem = stockItems[i];
        
        // Create rental item
        await connection.execute(
          `INSERT INTO rental_items (
            rental_id, equipment_id, stock_item_id, quantity, rental_price,
            rental_days, subtotal
          ) VALUES (?, ?, ?, 1, ?, ?, ?)`,
          [
            rentalId,
            item.equipment_id,
            stockItem?.id || null,
            item.rental_price,
            item.rental_days,
            item.rental_price * item.rental_days,
          ]
        );

        // Update stock item status
        if (stockItem) {
          await connection.execute(
            `UPDATE stock_items 
             SET availability_status = 'disewa', current_rental_id = ?
             WHERE id = ?`,
            [rentalId, stockItem.id]
          );
        }

        // Record stock movement
        await connection.execute(
          `INSERT INTO stock_movements (
            stock_item_id, equipment_id, rental_id, movement_type,
            quantity, movement_date
          ) VALUES (?, ?, ?, 'keluar', 1, NOW())`,
          [stockItem?.id || null, item.equipment_id, rentalId]
        );
      }

      // Update equipment stock
      await connection.execute(
        `UPDATE equipment 
         SET available_stock = available_stock - ?, rented_stock = rented_stock + ?
         WHERE id = ?`,
        [item.quantity, item.quantity, item.equipment_id]
      );
    }

    // Update customer stats
    await connection.execute(
      `UPDATE customers 
       SET total_rentals = total_rentals + 1
       WHERE id = ?`,
      [data.customer_id]
    );

    return rentalId;
  });
}

export async function processReturn(
  rentalId: number,
  items: Array<{
    rental_item_id: number;
    return_condition: 'baik' | 'rusak_ringan' | 'rusak_berat' | 'hilang';
    damage_fee?: number;
  }>
): Promise<void> {
  await transaction(async (connection) => {
    for (const item of items) {
      // Get rental item details
      const [itemRows] = await connection.execute<mysql.RowDataPacket[]>(
        `SELECT ri.*, e.id as equipment_id 
         FROM rental_items ri 
         JOIN equipment e ON ri.equipment_id = e.id
         WHERE ri.id = ?`,
        [item.rental_item_id]
      );
      const rentalItem = itemRows[0];
      if (!rentalItem) continue;

      // Update rental item
      await connection.execute(
        `UPDATE rental_items 
         SET returned_quantity = quantity, returned_date = NOW(),
             return_condition = ?, damage_fee = ?
         WHERE id = ?`,
        [item.return_condition, item.damage_fee || 0, item.rental_item_id]
      );

      // Update stock item
      if (rentalItem.stock_item_id) {
        const newStatus = item.return_condition === 'hilang' ? 'tidak_aktif' : 'tersedia';
        const conditionStatus = item.return_condition;

        await connection.execute(
          `UPDATE stock_items 
           SET availability_status = ?, condition_status = ?, current_rental_id = NULL
           WHERE id = ?`,
          [newStatus, conditionStatus, rentalItem.stock_item_id]
        );

        // Record stock movement
        await connection.execute(
          `INSERT INTO stock_movements (
            stock_item_id, equipment_id, rental_id, movement_type,
            quantity, movement_date, notes
          ) VALUES (?, ?, ?, 'retur', 1, NOW(), ?)`,
          [
            rentalItem.stock_item_id,
            rentalItem.equipment_id,
            rentalId,
            `Kondisi: ${item.return_condition}`,
          ]
        );
      }

      // Update equipment stock
      if (item.return_condition !== 'hilang') {
        await connection.execute(
          `UPDATE equipment 
           SET available_stock = available_stock + 1, rented_stock = rented_stock - 1
           WHERE id = ?`,
          [rentalItem.equipment_id]
        );
      } else {
        await connection.execute(
          `UPDATE equipment 
           SET rented_stock = rented_stock - 1, damaged_stock = damaged_stock + 1
           WHERE id = ?`,
          [rentalItem.equipment_id]
        );
      }
    }

    // Check if all items returned
    const [remainingItems] = await connection.execute<mysql.RowDataPacket[]>(
      `SELECT COUNT(*) as count FROM rental_items 
       WHERE rental_id = ? AND returned_quantity < quantity`,
      [rentalId]
    );

    if (remainingItems[0].count === 0) {
      await connection.execute(
        `UPDATE rentals SET status = 'returned', return_date = NOW() WHERE id = ?`,
        [rentalId]
      );
    }
  });
}

// =====================================================
// STOCK MOVEMENTS
// =====================================================

export async function getStockMovements(filters?: {
  equipment_id?: number;
  movement_type?: string;
  date_from?: string;
  date_to?: string;
}): Promise<StockMovement[]> {
  let sql = `
    SELECT sm.*, e.name as equipment_name, e.code as equipment_code,
           u.name as processor_name, r.rental_number
    FROM stock_movements sm
    JOIN equipment e ON sm.equipment_id = e.id
    LEFT JOIN users u ON sm.processed_by = u.id
    LEFT JOIN rentals r ON sm.rental_id = r.id
    WHERE 1=1
  `;
  const params: (string | number)[] = [];

  if (filters?.equipment_id) {
    sql += ' AND sm.equipment_id = ?';
    params.push(filters.equipment_id);
  }

  if (filters?.movement_type) {
    sql += ' AND sm.movement_type = ?';
    params.push(filters.movement_type);
  }

  if (filters?.date_from) {
    sql += ' AND DATE(sm.movement_date) >= ?';
    params.push(filters.date_from);
  }

  if (filters?.date_to) {
    sql += ' AND DATE(sm.movement_date) <= ?';
    params.push(filters.date_to);
  }

  sql += ' ORDER BY sm.movement_date DESC';

  return query<StockMovement[]>(sql, params);
}

// =====================================================
// DASHBOARD STATS
// =====================================================

export async function getDashboardStats(): Promise<DashboardStats> {
  const [equipmentStats] = await query<Array<{
    total: number;
    available: number;
    rented: number;
  }>>(
    `SELECT 
      SUM(total_stock) as total,
      SUM(available_stock) as available,
      SUM(rented_stock) as rented
    FROM equipment WHERE is_active = TRUE`
  );

  const [customerCount] = await query<Array<{ count: number }>>(
    'SELECT COUNT(*) as count FROM customers WHERE is_active = TRUE'
  );

  const [activeRentals] = await query<Array<{ count: number }>>(
    "SELECT COUNT(*) as count FROM rentals WHERE status = 'active'"
  );

  const [overdueRentals] = await query<Array<{ count: number }>>(
    "SELECT COUNT(*) as count FROM rentals WHERE status = 'active' AND due_date < CURDATE()"
  );

  const [monthlyRevenue] = await query<Array<{ total: number }>>(
    `SELECT COALESCE(SUM(paid_amount), 0) as total FROM rentals 
     WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())`
  );

  const [pendingPayments] = await query<Array<{ total: number }>>(
    `SELECT COALESCE(SUM(total_amount - paid_amount), 0) as total FROM rentals 
     WHERE payment_status IN ('unpaid', 'partial')`
  );

  return {
    totalEquipment: equipmentStats?.total || 0,
    availableUnits: equipmentStats?.available || 0,
    rentedUnits: equipmentStats?.rented || 0,
    totalCustomers: customerCount?.count || 0,
    activeRentals: activeRentals?.count || 0,
    overdueRentals: overdueRentals?.count || 0,
    monthlyRevenue: monthlyRevenue?.total || 0,
    pendingPayments: pendingPayments?.total || 0,
  };
}
