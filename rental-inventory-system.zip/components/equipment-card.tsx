'use client';

import { Equipment, formatCurrency } from '@/lib/data';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Package, CheckCircle2, AlertCircle } from 'lucide-react';

interface EquipmentCardProps {
  equipment: Equipment;
  onViewDetails?: (equipment: Equipment) => void;
}

export function EquipmentCard({ equipment, onViewDetails }: EquipmentCardProps) {
  const availabilityPercent = (equipment.available / equipment.stock) * 100;
  const isLowStock = availabilityPercent < 30;
  const isOutOfStock = equipment.available === 0;

  return (
    <Card className="group hover:border-primary/50 transition-all duration-300 bg-card overflow-hidden">
      <CardHeader className="p-0">
        <div className="h-48 bg-secondary flex items-center justify-center relative overflow-hidden">
          <Package className="w-20 h-20 text-muted-foreground/50 group-hover:scale-110 transition-transform duration-300" />
          <Badge 
            className="absolute top-3 right-3" 
            variant={isOutOfStock ? 'destructive' : isLowStock ? 'outline' : 'default'}
          >
            {equipment.category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <h3 className="font-semibold text-foreground mb-2 line-clamp-1">{equipment.name}</h3>
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{equipment.description}</p>
        
        {/* Price */}
        <div className="mb-3">
          <span className="text-xl font-bold text-primary">{formatCurrency(equipment.pricePerDay)}</span>
          <span className="text-sm text-muted-foreground"> / hari</span>
        </div>

        {/* Availability */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Ketersediaan</span>
            <div className="flex items-center gap-1">
              {isOutOfStock ? (
                <AlertCircle className="w-4 h-4 text-destructive" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-primary" />
              )}
              <span className={isOutOfStock ? 'text-destructive' : 'text-foreground'}>
                {equipment.available} / {equipment.stock} unit
              </span>
            </div>
          </div>
          <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-300 ${
                isOutOfStock ? 'bg-destructive' : isLowStock ? 'bg-yellow-500' : 'bg-primary'
              }`}
              style={{ width: `${availabilityPercent}%` }}
            />
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button 
          className="w-full" 
          variant={isOutOfStock ? 'outline' : 'default'}
          disabled={isOutOfStock}
          onClick={() => onViewDetails?.(equipment)}
        >
          {isOutOfStock ? 'Stok Habis' : 'Lihat Detail'}
        </Button>
      </CardFooter>
    </Card>
  );
}
