'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Menu, X, Wrench, Phone, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Wrench className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="hidden sm:block">
              <span className="font-bold text-lg text-foreground">Scaffolding</span>
              <span className="font-bold text-lg text-primary"> Shaka</span>
            </div>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
              Beranda
            </Link>
            <Link href="/catalog" className="text-muted-foreground hover:text-foreground transition-colors">
              Katalog Alat
            </Link>
            <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
              Tentang Kami
            </Link>
            <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
              Kontak
            </Link>
          </div>

          {/* CTA & Admin */}
          <div className="hidden md:flex items-center gap-3">
            <Link href="/admin">
              <Button variant="outline" size="sm">
                Admin Panel
              </Button>
            </Link>
            <Link href="/catalog">
              <Button size="sm">
                Cek Ketersediaan
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-foreground"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-3">
              <Link href="/" className="px-2 py-2 text-muted-foreground hover:text-foreground transition-colors">
                Beranda
              </Link>
              <Link href="/catalog" className="px-2 py-2 text-muted-foreground hover:text-foreground transition-colors">
                Katalog Alat
              </Link>
              <Link href="/about" className="px-2 py-2 text-muted-foreground hover:text-foreground transition-colors">
                Tentang Kami
              </Link>
              <Link href="/contact" className="px-2 py-2 text-muted-foreground hover:text-foreground transition-colors">
                Kontak
              </Link>
              <div className="flex flex-col gap-2 pt-3 border-t border-border">
                <Link href="/admin">
                  <Button variant="outline" className="w-full">
                    Admin Panel
                  </Button>
                </Link>
                <Link href="/catalog">
                  <Button className="w-full">
                    Cek Ketersediaan
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="bg-card border-t border-border mt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Wrench className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <span className="font-bold text-lg text-foreground">CV Scaffolding</span>
                <span className="font-bold text-lg text-primary"> Shaka</span>
              </div>
            </div>
            <p className="text-muted-foreground text-sm mb-4 max-w-md">
              Menyediakan layanan penyewaan alat konstruksi berkualitas dengan sistem manajemen terintegrasi. 
              Kami menerapkan metode FIFO untuk memastikan kualitas alat yang optimal.
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>Jl. Industri No. 123, Jakarta</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
              <Phone className="w-4 h-4" />
              <span>021-5551234</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Menu</h4>
            <div className="flex flex-col gap-2">
              <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Beranda
              </Link>
              <Link href="/catalog" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Katalog Alat
              </Link>
              <Link href="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Tentang Kami
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Kontak
              </Link>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Layanan</h4>
            <div className="flex flex-col gap-2">
              <span className="text-sm text-muted-foreground">Penyewaan Scaffolding</span>
              <span className="text-sm text-muted-foreground">Alat Berat</span>
              <span className="text-sm text-muted-foreground">Safety Equipment</span>
              <span className="text-sm text-muted-foreground">Konsultasi Proyek</span>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border mt-8 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © 2024 CV Scaffolding Shaka. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            Sistem Manajemen Persediaan dengan Metode FIFO
          </p>
        </div>
      </div>
    </footer>
  );
}
