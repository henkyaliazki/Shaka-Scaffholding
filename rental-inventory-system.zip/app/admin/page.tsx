import { Package, Users, FileText, TrendingUp, ArrowUpRight, ArrowDownRight, Boxes, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AdminHeader } from '@/components/admin/admin-layout';
import { getDashboardStats, rentalsData, stockMovementsData, formatCurrency, formatDate } from '@/lib/data';

export default function AdminDashboardPage() {
  const stats = getDashboardStats();
  const recentRentals = rentalsData.slice(0, 5);
  const recentMovements = stockMovementsData.slice(0, 5);

  return (
    <div>
      <AdminHeader 
        title="Dashboard" 
        description="Ringkasan data operasional CV Scaffolding Shaka"
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Alat</p>
                <p className="text-2xl font-bold text-foreground">{stats.totalEquipment.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Boxes className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-sm">
              <span className="text-muted-foreground">Unit tersedia:</span>
              <span className="font-medium text-foreground">{stats.totalAvailable}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Sedang Disewa</p>
                <p className="text-2xl font-bold text-foreground">{stats.totalRented.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-sm text-primary">
              <TrendingUp className="w-4 h-4" />
              <span>{stats.activeRentals} transaksi aktif</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Pelanggan</p>
                <p className="text-2xl font-bold text-foreground">{stats.totalCustomers}</p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-sm text-muted-foreground">
              <span>Pelanggan terdaftar</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Pendapatan Bulan Ini</p>
                <p className="text-2xl font-bold text-foreground">{formatCurrency(stats.monthlyRevenue)}</p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-sm text-primary">
              <ArrowUpRight className="w-4 h-4" />
              <span>+12% dari bulan lalu</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Rentals */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-semibold text-foreground">Transaksi Terbaru</CardTitle>
            <FileText className="w-5 h-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentRentals.map((rental) => (
                <div key={rental.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div>
                    <p className="font-medium text-foreground">{rental.customerName}</p>
                    <p className="text-sm text-muted-foreground">{rental.id} - {formatDate(rental.createdAt)}</p>
                  </div>
                  <div className="text-right">
                    <Badge 
                      variant={rental.status === 'active' ? 'default' : rental.status === 'returned' ? 'outline' : 'destructive'}
                    >
                      {rental.status === 'active' ? 'Aktif' : rental.status === 'returned' ? 'Selesai' : 'Overdue'}
                    </Badge>
                    <p className="text-sm text-muted-foreground mt-1">{formatCurrency(rental.totalPrice)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Stock Movements - FIFO Tracking */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold text-foreground">Pergerakan Stok (FIFO)</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">Tracking First-In, First-Out</p>
            </div>
            <AlertCircle className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentMovements.map((movement) => (
                <div key={movement.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      movement.type === 'in' ? 'bg-green-500/20' : 'bg-red-500/20'
                    }`}>
                      {movement.type === 'in' ? (
                        <ArrowDownRight className="w-5 h-5 text-green-500" />
                      ) : (
                        <ArrowUpRight className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{movement.equipmentName}</p>
                      <p className="text-sm text-muted-foreground">{movement.serialNumber}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant={movement.type === 'in' ? 'outline' : 'default'}>
                      {movement.type === 'in' ? 'Masuk' : 'Keluar'}
                    </Badge>
                    <p className="text-sm text-muted-foreground mt-1">{formatDate(movement.date)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* FIFO Info Banner */}
      <Card className="bg-primary/5 border-primary/20 mt-6">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <Package className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Sistem FIFO Aktif</h3>
              <p className="text-sm text-muted-foreground">
                Sistem secara otomatis memprioritaskan alat dengan tanggal masuk paling awal untuk disewakan terlebih dahulu. 
                Hal ini memastikan rotasi alat yang optimal dan meminimalkan risiko penurunan kualitas aset.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
