'use client';

import { useState } from 'react';
import { Plus, Search, Eye, Edit2, MoreHorizontal } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Label } from '@/components/ui/label';
import { AdminHeader } from '@/components/admin/admin-layout';
import { rentalsData, formatCurrency, formatDate } from '@/lib/data';

export default function RentalsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'returned' | 'overdue'>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const filteredRentals = rentalsData.filter((rental) => {
    const matchesSearch = rental.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          rental.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || rental.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const activeCount = rentalsData.filter(r => r.status === 'active').length;
  const returnedCount = rentalsData.filter(r => r.status === 'returned').length;
  const overdueCount = rentalsData.filter(r => r.status === 'overdue').length;

  return (
    <div>
      <AdminHeader 
        title="Transaksi Penyewaan" 
        description="Kelola transaksi penyewaan dan pengembalian alat"
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="bg-card border-border cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setStatusFilter('active')}>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Aktif</p>
            <p className="text-2xl font-bold text-foreground">{activeCount}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setStatusFilter('returned')}>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Selesai</p>
            <p className="text-2xl font-bold text-foreground">{returnedCount}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setStatusFilter('overdue')}>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Overdue</p>
            <p className="text-2xl font-bold text-destructive">{overdueCount}</p>
          </CardContent>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari transaksi atau pelanggan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-card border-border"
          />
        </div>
        <div className="flex gap-2">
          <Button 
            variant={statusFilter === 'all' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setStatusFilter('all')}
          >
            Semua
          </Button>
          <Button 
            variant={statusFilter === 'active' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setStatusFilter('active')}
          >
            Aktif
          </Button>
          <Button 
            variant={statusFilter === 'returned' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setStatusFilter('returned')}
          >
            Selesai
          </Button>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Transaksi Baru
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-lg">
            <DialogHeader>
              <DialogTitle>Transaksi Penyewaan Baru</DialogTitle>
              <DialogDescription>
                Buat transaksi penyewaan alat baru. Sistem akan otomatis menerapkan FIFO.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="customer">Pelanggan</Label>
                <Input id="customer" placeholder="Pilih atau cari pelanggan" className="bg-secondary" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="startDate">Tanggal Mulai</Label>
                  <Input id="startDate" type="date" className="bg-secondary" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="endDate">Tanggal Selesai</Label>
                  <Input id="endDate" type="date" className="bg-secondary" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label>Alat yang Disewa</Label>
                <div className="p-4 bg-secondary rounded-lg text-sm text-muted-foreground">
                  Klik untuk menambahkan alat ke dalam transaksi
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="notes">Catatan</Label>
                <Input id="notes" placeholder="Catatan proyek..." className="bg-secondary" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Batal</Button>
              <Button onClick={() => setIsAddDialogOpen(false)}>Simpan</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg">Daftar Transaksi</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border">
                  <TableHead className="text-muted-foreground">ID Transaksi</TableHead>
                  <TableHead className="text-muted-foreground">Pelanggan</TableHead>
                  <TableHead className="text-muted-foreground">Tanggal Sewa</TableHead>
                  <TableHead className="text-muted-foreground">Tanggal Kembali</TableHead>
                  <TableHead className="text-muted-foreground">Total</TableHead>
                  <TableHead className="text-muted-foreground">Status</TableHead>
                  <TableHead className="text-muted-foreground text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRentals.map((rental) => (
                  <TableRow key={rental.id} className="border-border">
                    <TableCell className="font-mono text-foreground">{rental.id}</TableCell>
                    <TableCell className="font-medium text-foreground">{rental.customerName}</TableCell>
                    <TableCell className="text-foreground">{formatDate(rental.startDate)}</TableCell>
                    <TableCell className="text-foreground">{formatDate(rental.endDate)}</TableCell>
                    <TableCell className="text-foreground">{formatCurrency(rental.totalPrice)}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          rental.status === 'active' ? 'default' : 
                          rental.status === 'returned' ? 'outline' : 'destructive'
                        }
                      >
                        {rental.status === 'active' ? 'Aktif' : 
                         rental.status === 'returned' ? 'Selesai' : 'Overdue'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-card border-border">
                          <DropdownMenuItem className="cursor-pointer">
                            <Eye className="w-4 h-4 mr-2" />
                            Lihat Detail
                          </DropdownMenuItem>
                          <DropdownMenuItem className="cursor-pointer">
                            <Edit2 className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          {rental.status === 'active' && (
                            <DropdownMenuItem className="cursor-pointer text-primary">
                              Proses Pengembalian
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
