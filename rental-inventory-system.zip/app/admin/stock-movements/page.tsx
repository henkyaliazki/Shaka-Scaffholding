'use client';

import { useState } from 'react';
import { Search, ArrowDownRight, ArrowUpRight, Filter, Package, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { AdminHeader } from '@/components/admin/admin-layout';
import { stockMovementsData, formatDate } from '@/lib/data';

export default function StockMovementsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'in' | 'out'>('all');

  const filteredMovements = stockMovementsData.filter((movement) => {
    const matchesSearch = movement.equipmentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          movement.serialNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || movement.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const inCount = stockMovementsData.filter(m => m.type === 'in').length;
  const outCount = stockMovementsData.filter(m => m.type === 'out').length;

  return (
    <div>
      <AdminHeader 
        title="Pergerakan Stok (FIFO)" 
        description="Tracking alur masuk-keluar alat dengan metode First-In, First-Out"
      />

      {/* FIFO Explanation */}
      <Card className="bg-primary/5 border-primary/20 mb-6">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <Package className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-2">Metode FIFO (First-In, First-Out)</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Sistem ini memastikan alat yang pertama kali masuk ke gudang akan diprioritaskan untuk disewakan terlebih dahulu.
                Hal ini mencegah penumpukan barang lama dan meminimalkan risiko penurunan kualitas aset fisik.
              </p>
              <div className="flex gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full" />
                  <span className="text-foreground">Barang Masuk: Dicatat dengan timestamp</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full" />
                  <span className="text-foreground">Barang Keluar: Prioritas tanggal masuk terlama</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="bg-card border-border cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setTypeFilter('all')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Pergerakan</p>
                <p className="text-xl font-bold text-foreground">{stockMovementsData.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border cursor-pointer hover:border-green-500/50 transition-colors" onClick={() => setTypeFilter('in')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
                <ArrowDownRight className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Barang Masuk</p>
                <p className="text-xl font-bold text-foreground">{inCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border cursor-pointer hover:border-red-500/50 transition-colors" onClick={() => setTypeFilter('out')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500/10 rounded-lg flex items-center justify-center">
                <ArrowUpRight className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Barang Keluar</p>
                <p className="text-xl font-bold text-foreground">{outCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari alat atau serial number..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-card border-border"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Button 
            variant={typeFilter === 'all' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setTypeFilter('all')}
          >
            Semua
          </Button>
          <Button 
            variant={typeFilter === 'in' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setTypeFilter('in')}
          >
            Masuk
          </Button>
          <Button 
            variant={typeFilter === 'out' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setTypeFilter('out')}
          >
            Keluar
          </Button>
        </div>
      </div>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg">Riwayat Pergerakan Stok</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border">
                  <TableHead className="text-muted-foreground">Tipe</TableHead>
                  <TableHead className="text-muted-foreground">Alat</TableHead>
                  <TableHead className="text-muted-foreground">Serial Number</TableHead>
                  <TableHead className="text-muted-foreground">Tanggal</TableHead>
                  <TableHead className="text-muted-foreground">ID Transaksi</TableHead>
                  <TableHead className="text-muted-foreground">Catatan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMovements.map((movement) => (
                  <TableRow key={movement.id} className="border-border">
                    <TableCell>
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        movement.type === 'in' ? 'bg-green-500/20' : 'bg-red-500/20'
                      }`}>
                        {movement.type === 'in' ? (
                          <ArrowDownRight className="w-5 h-5 text-green-500" />
                        ) : (
                          <ArrowUpRight className="w-5 h-5 text-red-500" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium text-foreground">{movement.equipmentName}</TableCell>
                    <TableCell className="font-mono text-foreground">{movement.serialNumber}</TableCell>
                    <TableCell className="text-foreground">{formatDate(movement.date)}</TableCell>
                    <TableCell>
                      {movement.rentalId ? (
                        <Badge variant="outline">{movement.rentalId}</Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground max-w-xs truncate">{movement.notes}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
