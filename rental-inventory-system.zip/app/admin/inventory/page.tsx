'use client';

import { useState } from 'react';
import { Plus, Search, Package, Edit2, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { AdminHeader } from '@/components/admin/admin-layout';
import { equipmentData, formatCurrency } from '@/lib/data';

export default function InventoryPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const filteredEquipment = equipmentData.filter((equipment) =>
    equipment.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    equipment.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalStock = equipmentData.reduce((acc, e) => acc + e.stock, 0);
  const totalAvailable = equipmentData.reduce((acc, e) => acc + e.available, 0);
  const totalRented = totalStock - totalAvailable;

  return (
    <div>
      <AdminHeader 
        title="Manajemen Persediaan" 
        description="Kelola stok alat konstruksi dengan sistem FIFO"
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Stok</p>
                <p className="text-xl font-bold text-foreground">{totalStock.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Tersedia</p>
                <p className="text-xl font-bold text-foreground">{totalAvailable.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-500/10 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-orange-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Disewakan</p>
                <p className="text-xl font-bold text-foreground">{totalRented.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari alat..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-card border-border"
          />
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Tambah Alat
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Tambah Alat Baru</DialogTitle>
              <DialogDescription>
                Tambahkan alat konstruksi baru ke dalam persediaan
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Nama Alat</Label>
                <Input id="name" placeholder="Scaffolding Frame 1.7m" className="bg-secondary" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="category">Kategori</Label>
                <Input id="category" placeholder="Scaffolding" className="bg-secondary" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="stock">Jumlah Stok</Label>
                  <Input id="stock" type="number" placeholder="100" className="bg-secondary" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="price">Harga / Hari</Label>
                  <Input id="price" type="number" placeholder="15000" className="bg-secondary" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Deskripsi</Label>
                <Input id="description" placeholder="Deskripsi alat..." className="bg-secondary" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Batal</Button>
              <Button onClick={() => setIsAddDialogOpen(false)}>Simpan</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* FIFO Info */}
      <Card className="bg-primary/5 border-primary/20 mb-6">
        <CardContent className="p-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-primary flex-shrink-0" />
          <p className="text-sm text-foreground">
            <strong>Metode FIFO:</strong> Sistem secara otomatis memprioritaskan alat dengan tanggal masuk paling awal untuk disewakan.
          </p>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg">Daftar Alat Konstruksi</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border">
                  <TableHead className="text-muted-foreground">Nama Alat</TableHead>
                  <TableHead className="text-muted-foreground">Kategori</TableHead>
                  <TableHead className="text-muted-foreground">Stok Total</TableHead>
                  <TableHead className="text-muted-foreground">Tersedia</TableHead>
                  <TableHead className="text-muted-foreground">Harga/Hari</TableHead>
                  <TableHead className="text-muted-foreground">Status</TableHead>
                  <TableHead className="text-muted-foreground text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEquipment.map((equipment) => {
                  const availabilityPercent = (equipment.available / equipment.stock) * 100;
                  const isLowStock = availabilityPercent < 30;
                  const isOutOfStock = equipment.available === 0;

                  return (
                    <TableRow key={equipment.id} className="border-border">
                      <TableCell className="font-medium text-foreground">
                        {equipment.name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{equipment.category}</Badge>
                      </TableCell>
                      <TableCell className="text-foreground">{equipment.stock}</TableCell>
                      <TableCell>
                        <span className={isOutOfStock ? 'text-destructive' : isLowStock ? 'text-yellow-500' : 'text-foreground'}>
                          {equipment.available}
                        </span>
                      </TableCell>
                      <TableCell className="text-foreground">{formatCurrency(equipment.pricePerDay)}</TableCell>
                      <TableCell>
                        <Badge 
                          variant={isOutOfStock ? 'destructive' : isLowStock ? 'outline' : 'default'}
                        >
                          {isOutOfStock ? 'Habis' : isLowStock ? 'Stok Rendah' : 'Tersedia'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Edit2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
