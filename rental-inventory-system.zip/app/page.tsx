import Link from 'next/link';
import { ArrowRight, Package, Clock, Shield, TrendingUp, CheckCircle2, Users, Boxes } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Navbar, Footer } from '@/components/layout/navbar';
import { equipmentData, getDashboardStats } from '@/lib/data';
import { EquipmentCard } from '@/components/equipment-card';

export default function HomePage() {
  const stats = getDashboardStats();
  const featuredEquipment = equipmentData.slice(0, 4);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
                <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                <span className="text-sm text-primary font-medium">Sistem Manajemen FIFO</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight text-balance">
                Penyewaan Alat Konstruksi{' '}
                <span className="text-primary">Terpercaya</span>
              </h1>
              <p className="text-lg text-muted-foreground mb-8 max-w-xl leading-relaxed">
                CV Scaffolding Shaka menyediakan solusi lengkap untuk kebutuhan alat konstruksi Anda. 
                Cek ketersediaan alat secara real-time dan nikmati kemudahan penyewaan dengan sistem terintegrasi.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/catalog">
                  <Button size="lg" className="w-full sm:w-auto">
                    Lihat Katalog
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    Hubungi Kami
                  </Button>
                </Link>
              </div>
            </div>

            {/* Hero Stats */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <Boxes className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-1">{stats.totalEquipment.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Total Unit Alat</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <CheckCircle2 className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-1">{stats.totalAvailable.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Unit Tersedia</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-1">{stats.totalCustomers}+</div>
                  <div className="text-sm text-muted-foreground">Pelanggan Aktif</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-1">{stats.activeRentals}</div>
                  <div className="text-sm text-muted-foreground">Transaksi Aktif</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Mengapa Memilih Kami?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Kami menghadirkan sistem manajemen persediaan modern dengan metode FIFO untuk memastikan kualitas alat terbaik
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-card border-border">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Real-time Availability</h3>
                <p className="text-sm text-muted-foreground">
                  Cek ketersediaan alat konstruksi kapan saja dan di mana saja melalui platform web kami
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Package className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Metode FIFO</h3>
                <p className="text-sm text-muted-foreground">
                  Sistem FIFO memastikan alat yang lebih lama di gudang diprioritaskan untuk disewakan terlebih dahulu
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Kualitas Terjamin</h3>
                <p className="text-sm text-muted-foreground">
                  Semua alat melalui pengecekan rutin dan pemeliharaan berkala untuk keamanan penggunaan
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Equipment */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">Alat Tersedia</h2>
              <p className="text-muted-foreground">Lihat beberapa alat konstruksi yang tersedia untuk disewa</p>
            </div>
            <Link href="/catalog">
              <Button variant="outline">
                Lihat Semua
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredEquipment.map((equipment) => (
              <EquipmentCard key={equipment.id} equipment={equipment} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                Butuh Alat Konstruksi untuk Proyek Anda?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                Hubungi kami sekarang untuk konsultasi gratis dan dapatkan penawaran terbaik untuk kebutuhan proyek konstruksi Anda
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/catalog">
                  <Button size="lg">
                    Cek Katalog Alat
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button size="lg" variant="outline">
                    Hubungi Kami
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}
