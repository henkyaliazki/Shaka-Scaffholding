import { CheckCircle2, Target, Users, Shield, Package, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Navbar, Footer } from '@/components/layout/navbar';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Tentang Kami</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg leading-relaxed">
              CV Scaffolding Shaka adalah perusahaan penyewaan alat konstruksi yang berkomitmen 
              memberikan layanan terbaik dengan sistem manajemen modern.
            </p>
          </div>

          {/* Vision & Mission */}
          <div className="grid md:grid-cols-2 gap-6 mb-16">
            <Card className="bg-card border-border">
              <CardContent className="p-8">
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-6">
                  <Target className="w-7 h-7 text-primary" />
                </div>
                <h2 className="text-xl font-bold text-foreground mb-4">Visi</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Menjadi perusahaan penyewaan alat konstruksi terdepan yang mengutamakan kualitas, 
                  efisiensi, dan kepuasan pelanggan melalui penerapan teknologi modern.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-8">
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-6">
                  <CheckCircle2 className="w-7 h-7 text-primary" />
                </div>
                <h2 className="text-xl font-bold text-foreground mb-4">Misi</h2>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                    Menyediakan alat konstruksi berkualitas tinggi dengan harga kompetitif
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                    Menerapkan sistem manajemen FIFO untuk menjaga kualitas alat
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                    Memberikan kemudahan akses informasi ketersediaan alat secara real-time
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Why FIFO */}
          <div className="mb-16">
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                Mengapa Kami Menggunakan Metode FIFO?
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                First-In, First-Out adalah metode manajemen persediaan yang memastikan alat dengan 
                tanggal masuk paling awal diprioritaskan untuk disewakan terlebih dahulu.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="bg-card border-border">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Package className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">Rotasi Optimal</h3>
                  <p className="text-sm text-muted-foreground">
                    Mencegah penumpukan alat lama di gudang yang dapat menurunkan kualitas fisik
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Shield className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">Kualitas Terjaga</h3>
                  <p className="text-sm text-muted-foreground">
                    Alat yang disewakan selalu dalam kondisi prima karena rotasi yang terstruktur
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">Efisiensi Aset</h3>
                  <p className="text-sm text-muted-foreground">
                    Meminimalkan risiko penyusutan nilai guna aset dan memaksimalkan utilisasi
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Values */}
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-8">
              <h2 className="text-xl font-bold text-foreground mb-6 text-center">Nilai-Nilai Kami</h2>
              <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">Integritas</h3>
                  <p className="text-sm text-muted-foreground">Jujur dan transparan</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">Pelayanan</h3>
                  <p className="text-sm text-muted-foreground">Kepuasan pelanggan</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Shield className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">Keamanan</h3>
                  <p className="text-sm text-muted-foreground">Standar keselamatan</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">Inovasi</h3>
                  <p className="text-sm text-muted-foreground">Teknologi modern</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
