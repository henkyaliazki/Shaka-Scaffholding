'use client';

import { useState } from 'react';
import { Search, Filter, Package } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Navbar, Footer } from '@/components/layout/navbar';
import { equipmentData, getCategories, formatCurrency, Equipment } from '@/lib/data';
import { EquipmentCard } from '@/components/equipment-card';

export default function CatalogPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null);
  
  const categories = ['all', ...getCategories()];

  const filteredEquipment = equipmentData.filter((equipment) => {
    const matchesSearch = equipment.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          equipment.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || equipment.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">Katalog Alat Konstruksi</h1>
            <p className="text-muted-foreground">
              Cek ketersediaan alat secara real-time dan temukan yang Anda butuhkan
            </p>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Cari alat konstruksi..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-card border-border"
              />
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
              <Filter className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="flex-shrink-0"
                >
                  {category === 'all' ? 'Semua' : category}
                </Button>
              ))}
            </div>
          </div>

          {/* Results Info */}
          <div className="flex items-center justify-between mb-6">
            <p className="text-sm text-muted-foreground">
              Menampilkan {filteredEquipment.length} alat
            </p>
            <Badge variant="outline" className="text-primary border-primary/30">
              Update Real-time
            </Badge>
          </div>

          {/* Equipment Grid */}
          {filteredEquipment.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredEquipment.map((equipment) => (
                <EquipmentCard
                  key={equipment.id}
                  equipment={equipment}
                  onViewDetails={setSelectedEquipment}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Package className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Tidak Ada Hasil</h3>
              <p className="text-muted-foreground">
                Coba ubah kata kunci pencarian atau filter kategori
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Equipment Detail Dialog */}
      <Dialog open={!!selectedEquipment} onOpenChange={() => setSelectedEquipment(null)}>
        <DialogContent className="bg-card border-border max-w-lg">
          {selectedEquipment && (
            <>
              <DialogHeader>
                <DialogTitle className="text-foreground">{selectedEquipment.name}</DialogTitle>
                <DialogDescription>{selectedEquipment.description}</DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 mt-4">
                {/* Image Placeholder */}
                <div className="h-48 bg-secondary rounded-lg flex items-center justify-center">
                  <Package className="w-16 h-16 text-muted-foreground/50" />
                </div>

                {/* Price */}
                <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                  <span className="text-muted-foreground">Harga Sewa</span>
                  <div>
                    <span className="text-2xl font-bold text-primary">{formatCurrency(selectedEquipment.pricePerDay)}</span>
                    <span className="text-muted-foreground"> / hari</span>
                  </div>
                </div>

                {/* Availability */}
                <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                  <span className="text-muted-foreground">Ketersediaan</span>
                  <span className="font-semibold text-foreground">
                    {selectedEquipment.available} / {selectedEquipment.stock} unit
                  </span>
                </div>

                {/* Specifications */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Spesifikasi</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(selectedEquipment.specifications).map(([key, value]) => (
                      <div key={key} className="p-3 bg-secondary rounded-lg">
                        <div className="text-xs text-muted-foreground">{key}</div>
                        <div className="text-sm font-medium text-foreground">{value}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action */}
                <div className="flex gap-3 pt-4">
                  <Button 
                    className="flex-1" 
                    disabled={selectedEquipment.available === 0}
                  >
                    {selectedEquipment.available === 0 ? 'Stok Habis' : 'Hubungi untuk Sewa'}
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedEquipment(null)}>
                    Tutup
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}
