// Types for the application
export interface Equipment {
  id: string;
  name: string;
  category: string;
  description: string;
  pricePerDay: number;
  stock: number;
  available: number;
  image: string;
  specifications: Record<string, string>;
}

export interface InventoryItem {
  id: string;
  equipmentId: string;
  serialNumber: string;
  dateIn: Date;
  status: 'available' | 'rented' | 'maintenance';
  condition: 'good' | 'fair' | 'poor';
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  idNumber: string;
  createdAt: Date;
}

export interface Rental {
  id: string;
  customerId: string;
  customerName: string;
  items: RentalItem[];
  startDate: Date;
  endDate: Date;
  totalPrice: number;
  status: 'active' | 'returned' | 'overdue';
  notes: string;
  createdAt: Date;
}

export interface RentalItem {
  equipmentId: string;
  equipmentName: string;
  inventoryItemId: string;
  serialNumber: string;
  quantity: number;
  pricePerDay: number;
}

export interface StockMovement {
  id: string;
  equipmentId: string;
  equipmentName: string;
  inventoryItemId: string;
  serialNumber: string;
  type: 'in' | 'out';
  date: Date;
  rentalId?: string;
  notes: string;
}

// Sample equipment data
export const equipmentData: Equipment[] = [
  {
    id: '1',
    name: 'Scaffolding Frame 1.7m',
    category: 'Scaffolding',
    description: 'Frame scaffolding standar ukuran 1.7 meter untuk konstruksi bangunan bertingkat',
    pricePerDay: 15000,
    stock: 200,
    available: 145,
    image: '/equipment/scaffolding-frame.jpg',
    specifications: {
      'Tinggi': '1.7 meter',
      'Material': 'Baja Galvanis',
      'Kapasitas Beban': '500 kg',
      'Berat': '15 kg'
    }
  },
  {
    id: '2',
    name: 'Cross Brace Scaffolding',
    category: 'Scaffolding',
    description: 'Penguat silang untuk scaffolding, menjaga kestabilan struktur',
    pricePerDay: 5000,
    stock: 400,
    available: 320,
    image: '/equipment/cross-brace.jpg',
    specifications: {
      'Panjang': '1.2 meter',
      'Material': 'Baja',
      'Berat': '4 kg'
    }
  },
  {
    id: '3',
    name: 'Scaffolding Plank',
    category: 'Scaffolding',
    description: 'Papan lantai scaffolding untuk platform kerja',
    pricePerDay: 8000,
    stock: 300,
    available: 210,
    image: '/equipment/scaffolding-plank.jpg',
    specifications: {
      'Panjang': '2 meter',
      'Lebar': '30 cm',
      'Material': 'Baja',
      'Kapasitas Beban': '300 kg'
    }
  },
  {
    id: '4',
    name: 'Base Jack',
    category: 'Scaffolding',
    description: 'Kaki dasar scaffolding yang dapat disesuaikan ketinggiannya',
    pricePerDay: 3000,
    stock: 250,
    available: 180,
    image: '/equipment/base-jack.jpg',
    specifications: {
      'Tinggi Adjustable': '0-60 cm',
      'Material': 'Baja',
      'Diameter Base': '15 cm'
    }
  },
  {
    id: '5',
    name: 'Concrete Mixer 350L',
    category: 'Alat Berat',
    description: 'Mesin pengaduk beton kapasitas 350 liter dengan motor diesel',
    pricePerDay: 250000,
    stock: 15,
    available: 8,
    image: '/equipment/concrete-mixer.jpg',
    specifications: {
      'Kapasitas': '350 Liter',
      'Motor': 'Diesel 8 HP',
      'Berat': '280 kg'
    }
  },
  {
    id: '6',
    name: 'Vibrator Beton',
    category: 'Alat Berat',
    description: 'Vibrator untuk pemadatan beton cor',
    pricePerDay: 150000,
    stock: 20,
    available: 12,
    image: '/equipment/vibrator.jpg',
    specifications: {
      'Panjang Selang': '6 meter',
      'Diameter Head': '50 mm',
      'Motor': 'Bensin 5.5 HP'
    }
  },
  {
    id: '7',
    name: 'Stamper/Compactor',
    category: 'Alat Berat',
    description: 'Mesin pemadat tanah untuk persiapan fondasi',
    pricePerDay: 200000,
    stock: 10,
    available: 6,
    image: '/equipment/stamper.jpg',
    specifications: {
      'Gaya Impact': '10 kN',
      'Motor': 'Bensin 4 HP',
      'Berat': '75 kg'
    }
  },
  {
    id: '8',
    name: 'Safety Harness Full Body',
    category: 'Safety',
    description: 'Sabuk pengaman full body untuk bekerja di ketinggian',
    pricePerDay: 25000,
    stock: 50,
    available: 35,
    image: '/equipment/safety-harness.jpg',
    specifications: {
      'Kapasitas Beban': '150 kg',
      'Material': 'Polyester',
      'Standar': 'SNI'
    }
  }
];

// Sample customers data
export const customersData: Customer[] = [
  {
    id: '1',
    name: 'PT Bangun Sejahtera',
    phone: '021-5551234',
    email: 'info@banguns.co.id',
    address: 'Jl. Sudirman No. 123, Jakarta',
    idNumber: '1234567890123456',
    createdAt: new Date('2024-01-15')
  },
  {
    id: '2',
    name: 'CV Maju Jaya Konstruksi',
    phone: '022-4445678',
    email: 'majujaya@gmail.com',
    address: 'Jl. Asia Afrika No. 45, Bandung',
    idNumber: '2345678901234567',
    createdAt: new Date('2024-02-20')
  },
  {
    id: '3',
    name: 'Budi Santoso',
    phone: '0812-3456-7890',
    email: 'budisantoso@gmail.com',
    address: 'Jl. Pahlawan No. 78, Surabaya',
    idNumber: '3456789012345678',
    createdAt: new Date('2024-03-10')
  }
];

// Sample rentals data
export const rentalsData: Rental[] = [
  {
    id: 'R001',
    customerId: '1',
    customerName: 'PT Bangun Sejahtera',
    items: [
      {
        equipmentId: '1',
        equipmentName: 'Scaffolding Frame 1.7m',
        inventoryItemId: 'INV001',
        serialNumber: 'SF-2024-001',
        quantity: 50,
        pricePerDay: 15000
      },
      {
        equipmentId: '2',
        equipmentName: 'Cross Brace Scaffolding',
        inventoryItemId: 'INV002',
        serialNumber: 'CB-2024-001',
        quantity: 100,
        pricePerDay: 5000
      }
    ],
    startDate: new Date('2024-11-01'),
    endDate: new Date('2024-11-30'),
    totalPrice: 37500000,
    status: 'active',
    notes: 'Proyek pembangunan gedung perkantoran',
    createdAt: new Date('2024-10-28')
  },
  {
    id: 'R002',
    customerId: '2',
    customerName: 'CV Maju Jaya Konstruksi',
    items: [
      {
        equipmentId: '5',
        equipmentName: 'Concrete Mixer 350L',
        inventoryItemId: 'INV003',
        serialNumber: 'CM-2024-001',
        quantity: 2,
        pricePerDay: 250000
      }
    ],
    startDate: new Date('2024-11-05'),
    endDate: new Date('2024-11-12'),
    totalPrice: 4000000,
    status: 'active',
    notes: 'Proyek perumahan cluster',
    createdAt: new Date('2024-11-03')
  },
  {
    id: 'R003',
    customerId: '3',
    customerName: 'Budi Santoso',
    items: [
      {
        equipmentId: '1',
        equipmentName: 'Scaffolding Frame 1.7m',
        inventoryItemId: 'INV004',
        serialNumber: 'SF-2024-002',
        quantity: 10,
        pricePerDay: 15000
      }
    ],
    startDate: new Date('2024-10-15'),
    endDate: new Date('2024-10-22'),
    totalPrice: 1050000,
    status: 'returned',
    notes: 'Renovasi rumah',
    createdAt: new Date('2024-10-14')
  }
];

// Sample stock movements data (FIFO tracking)
export const stockMovementsData: StockMovement[] = [
  {
    id: 'SM001',
    equipmentId: '1',
    equipmentName: 'Scaffolding Frame 1.7m',
    inventoryItemId: 'INV001',
    serialNumber: 'SF-2024-001',
    type: 'in',
    date: new Date('2024-01-10'),
    notes: 'Pembelian awal'
  },
  {
    id: 'SM002',
    equipmentId: '1',
    equipmentName: 'Scaffolding Frame 1.7m',
    inventoryItemId: 'INV001',
    serialNumber: 'SF-2024-001',
    type: 'out',
    date: new Date('2024-11-01'),
    rentalId: 'R001',
    notes: 'Disewa oleh PT Bangun Sejahtera'
  },
  {
    id: 'SM003',
    equipmentId: '5',
    equipmentName: 'Concrete Mixer 350L',
    inventoryItemId: 'INV003',
    serialNumber: 'CM-2024-001',
    type: 'in',
    date: new Date('2024-02-15'),
    notes: 'Pembelian unit baru'
  },
  {
    id: 'SM004',
    equipmentId: '5',
    equipmentName: 'Concrete Mixer 350L',
    inventoryItemId: 'INV003',
    serialNumber: 'CM-2024-001',
    type: 'out',
    date: new Date('2024-11-05'),
    rentalId: 'R002',
    notes: 'Disewa oleh CV Maju Jaya Konstruksi'
  }
];

// Helper functions
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  }).format(date);
}

export function getCategories(): string[] {
  return [...new Set(equipmentData.map(e => e.category))];
}

export function getEquipmentByCategory(category: string): Equipment[] {
  if (category === 'all') return equipmentData;
  return equipmentData.filter(e => e.category === category);
}

export function getEquipmentById(id: string): Equipment | undefined {
  return equipmentData.find(e => e.id === id);
}

// Dashboard stats
export function getDashboardStats() {
  const totalEquipment = equipmentData.reduce((acc, e) => acc + e.stock, 0);
  const totalAvailable = equipmentData.reduce((acc, e) => acc + e.available, 0);
  const activeRentals = rentalsData.filter(r => r.status === 'active').length;
  const totalCustomers = customersData.length;
  const monthlyRevenue = rentalsData
    .filter(r => {
      const now = new Date();
      return r.createdAt.getMonth() === now.getMonth() && 
             r.createdAt.getFullYear() === now.getFullYear();
    })
    .reduce((acc, r) => acc + r.totalPrice, 0);

  return {
    totalEquipment,
    totalAvailable,
    totalRented: totalEquipment - totalAvailable,
    activeRentals,
    totalCustomers,
    monthlyRevenue
  };
}
